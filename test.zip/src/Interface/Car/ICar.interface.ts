export interface ICAR {
  id: string,
  unlimitedMileage: boolean,
  pickupLocation: Array<string>,
  driverAge: string,
  cancellationDetails: ICancellationDetails,
  fare: IFare,
  vehicle: IVehicle,
}

interface ICancellationDetails {
  isCancellationFree: boolean,
  freeCancellationEndDate: string
}

interface IFare {
  totalAmount: number,
  perDay: number
}

interface IVehicle {
  name: string,
  type: string,
  image: string,
  specifications: ISpecification,
}

interface ISpecification {
  baggageCapacity: string
  passengerCapacity: string
}

// <<<<<<<<<<<<< search paload type >>>>>>>>>>
export interface ICarsSearchPayload {
  pickupLocation: string,
  pickUpDate: string,
  pickUpTime: string,
  dropOffDate: string,
  dropOffTime: string,
  driverAge: string,
}

