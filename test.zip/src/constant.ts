export interface ITab  {
  id: string;
  label: string;
  icon: string;
  link: string;
}

export const TABS : ITab [] = [
  {
    id: '8526984129874',
    label: 'Cars',
    icon: 'directions_car_filled',
    link: '/cars'
  },
  {
    id: '98745745845845',
    label: 'Flights',
    icon: 'flight',
    link: '/flights'
  },
  {
    id: '545878954126845',
    label: 'Hotels',
    icon: 'hotel',
    link: '/hotels'
  },
  {
    id: '758526218585085',
    label: 'Cruises',
    icon: 'sailing',
    link: '/cruises'
  }
]
