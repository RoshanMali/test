import {ICAR, ICarsSearchPayload} from "../Interface/Car/ICar.interface";
import {createAction, props} from '@ngrx/store';

export const GET_CARS = createAction(
  "[GET_CARS]",
  props<{payload: ICarsSearchPayload}>()
);

export const CARS_LOADED = createAction(
  "[CARS_LOADED]",
  props<{allCars:ICAR[]}>()
);
