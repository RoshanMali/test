import {ICAR} from "../Interface/Car/ICar.interface";

export interface AppState {
  cars: ICAR[];
}
