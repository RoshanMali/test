import {Actions, createEffect, ofType} from "@ngrx/effects";
import {HttpService} from "../app/http.service";
import {Injectable} from "@angular/core";
import {map, mergeMap} from "rxjs/operators";

@Injectable()
export class CarsEffects {
  constructor(
    private actions$: Actions,
    private httpSevice: HttpService
  ) {}

  getCars$ = createEffect(() => {
      return this.actions$.pipe(
        ofType('[GET_CARS]'),
        mergeMap((action: any ) =>
          this.httpSevice
            .getCars(action.payload)
            .pipe(map((data) => ({type: '[CARS_LOADED]', allCars: data})))
        )
      );
    }
  );
}
