import {ICAR} from "../Interface/Car/ICar.interface";
import {CARS_LOADED} from "./cars.action";
import {createReducer, on} from "@ngrx/store";

const initialState: Array<ICAR> = [];

const _carsReducer = createReducer(
  initialState,
  on(CARS_LOADED, (state, {allCars}) => {
    return [...allCars];
  })
);


export function carsReducer(state: any, action: any) {
  return _carsReducer(state, action);
}
