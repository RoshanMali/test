import {createSelector} from '@ngrx/store';
import {AppState} from "./state.model";
import {ICAR, ICarsSearchPayload} from "../Interface/Car/ICar.interface";

export const carsSelector = (state: AppState) => state.cars;

export const getCars = (searchQuery: ICarsSearchPayload) => createSelector(
  carsSelector,
  (cars: ICAR[]) => {
    return [...cars.filter((x: ICAR) => x.pickupLocation.map(x => x.toLowerCase()).includes(searchQuery.pickupLocation.toLowerCase()) && x.driverAge === searchQuery.driverAge)];
  }
);

export const sortCars = (code: number) => createSelector(
  carsSelector,
  (cars: ICAR[]) => {
    let result = []
    switch (code) {
      case 1001:
        result = [...cars.slice().sort((a, b) => a.fare.perDay - b.fare.perDay)];
        break;
      case 1002:
        result = [...cars.slice().sort((a, b) => b.fare.perDay - a.fare.perDay)];
        break;
      case 1003:
        result = [...cars.slice().sort((a, b) => stringCompare(a, b, 'name'))];
        break;
      case 1004:
        result = [...cars.slice().sort((a, b) => stringCompare(b, a, 'name'))];
        break;
      case 1005:
        result = [...cars.slice().sort((a, b) => stringCompare(a, b, 'type'))];
        break;
      case 1006:
        result = [...cars.slice().sort((a, b) => stringCompare(b, a, 'type'))];
        break;
      default:
        result = cars
    }
    return result
  }
);

function stringCompare(a: any, b: any, prop: string) {
  if (a.vehicle[prop] < b.vehicle[prop]) {
    return -1;
  }
  if (a.vehicle[prop] > b.vehicle[prop]) {
    return 1;
  }
  return 0;
}
