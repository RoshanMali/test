import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cruises',
  templateUrl: './cruises.component.html',
  styleUrls: ['./cruises.component.scss']
})
export class CruisesComponent implements OnInit {
  constructor() { }
  ngOnInit(): void {
  }
}
