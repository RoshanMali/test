import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';
import {ICAR, ICarsSearchPayload} from "../Interface/Car/ICar.interface";
import {Observable} from "rxjs";

@Injectable({
  providedIn: 'root'
})
export class HttpService {
  constructor(private http: HttpClient) {}

  getCars(payload: ICarsSearchPayload): Observable<ICAR[]>{
    return this.http.get<Observable<ICAR[]>>('http://localhost:3000/carMockItineraries').pipe(map((response: any) => response.CarItineraries));
  }
}
