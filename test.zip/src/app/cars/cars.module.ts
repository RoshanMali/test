import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {CarsComponent} from "./cars.component";
import {RouterModule} from "@angular/router";
import {MatFormFieldModule} from "@angular/material/form-field";
import {FormsModule, ReactiveFormsModule} from "@angular/forms";
import {MatInputModule} from "@angular/material/input";
import {MatCardModule} from "@angular/material/card";
import {MatButtonModule} from "@angular/material/button";
import {MatIconModule} from "@angular/material/icon";
import {MatDatepickerModule} from "@angular/material/datepicker";
import {MatSelectModule} from "@angular/material/select";
import {MatOptionModule} from "@angular/material/core";
import {FlexLayoutModule} from "@angular/flex-layout";
import {SearchResultComponent, SortDialog} from './search-result/search-result.component';
import {MatDividerModule} from "@angular/material/divider";
import {MatButtonToggleModule} from "@angular/material/button-toggle";
import {MatRadioModule} from "@angular/material/radio";
import {MatDialogModule} from "@angular/material/dialog";
import {TranslocoModule} from "@ngneat/transloco";

@NgModule({
  declarations: [
    CarsComponent,
    SearchResultComponent,
    SortDialog
  ],
  imports: [
    CommonModule,
    RouterModule.forChild([
      {
        path: '',
        component: CarsComponent
      },
      {
        path: 'search-result',
        component: SearchResultComponent
      }
    ]),
    MatFormFieldModule,
    ReactiveFormsModule,
    MatInputModule,
    MatCardModule,
    MatButtonModule,
    MatIconModule,
    MatDatepickerModule,
    MatSelectModule,
    MatOptionModule,
    FlexLayoutModule,
    MatDividerModule,
    MatButtonToggleModule,
    MatRadioModule,
    FormsModule,
    MatDialogModule,
    TranslocoModule
  ]
})
export class CarsModule { }
