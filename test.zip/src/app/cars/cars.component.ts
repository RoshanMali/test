import {Component, OnInit} from '@angular/core';
import {FormControl, FormGroup, Validators} from "@angular/forms";
import {Store} from "@ngrx/store";
import {ICAR} from "../../Interface/Car/ICar.interface";
import {Router} from "@angular/router";

@Component({
  selector: 'app-cars',
  templateUrl: './cars.component.html',
  styleUrls: ['./cars.component.scss']
})
export class CarsComponent implements OnInit {
  searchForm: FormGroup = new FormGroup({
    pickupLocation: new FormControl(null, Validators.required),
    pickUpDate: new FormControl(null, Validators.required),
    pickUpTime: new FormControl(null, Validators.required),
    dropOffDate: new FormControl(null, Validators.required),
    dropOffTime: new FormControl(null, Validators.required),
    driverAge: new FormControl(''),
  });
  driverAgeArr = ['1 - 20', '20 - 30', '30+'];

  constructor(
    private store: Store<{ cars: ICAR[] }>,
    private router: Router
  ) {
  }

  ngOnInit(): void {
    localStorage.removeItem('searchQuery')  //  storing in local storage because if search result is required even after refreshing the browser.
  }

  submit() {
    localStorage.setItem('searchQuery', JSON.stringify(this.searchForm.value)) //  storing in local storage because if search result is required even after refreshing the browser.
    this.router.navigate(['/cars/search-result'])
  }
}
