import {Component, Inject, OnInit} from '@angular/core';
import {select, Store} from "@ngrx/store";
import {ICAR} from "../../../Interface/Car/ICar.interface";
import {getCars, sortCars} from "../../../store/cars.selector";
import {GET_CARS} from "../../../store/cars.action";
import {Observable} from "rxjs";
import {shareReplay} from "rxjs/operators";
import {MAT_DIALOG_DATA, MatDialog, MatDialogRef} from "@angular/material/dialog";

@Component({
  selector: 'app-search-result',
  templateUrl: './search-result.component.html',
  styleUrls: ['./search-result.component.scss']
})
export class SearchResultComponent implements OnInit {
  searchQuery = JSON.parse(localStorage.getItem('searchQuery') || '')
  albumIds$: Observable<ICAR[]> = this.store.pipe(select(getCars(this.searchQuery))).pipe(shareReplay());
  sortType = ''
  constructor(
    private store: Store<{ cars: ICAR[] }>,
    public dialog: MatDialog
  ) { }

  ngOnInit(): void {
    this.store.dispatch(GET_CARS({payload: this.searchQuery}))
  }

  sort() {
    const dialogRef = this.dialog.open(SortDialog, {
      width: '250px',
      data: this.sortType
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result.code) {
        this.sortType = result
        this.albumIds$ = this.store.pipe(select(sortCars(result.code)))
      }
    });
  }
}


@Component({
  selector: 'sort-dialog',
  template: `
    <label id="example-radio-group-label">Sort By</label>
    <mat-radio-group
      aria-labelledby="example-radio-group-label"
      class="example-radio-group"
      [(ngModel)]="data"
      (change)="selected()"
    >
      <mat-radio-button *ngFor="let sortBy of criteria" [value]="sortBy">
        {{sortBy.label}}
      </mat-radio-button>
    </mat-radio-group>
  `,
  styleUrls: ['./search-result.component.scss']
})
export class SortDialog {
  criteria = Criteria
  constructor(
    public dialogRef: MatDialogRef<SortDialog>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {}
  selected(): void {
    this.dialogRef.close(this.data);
  }
}

const Criteria = [
  {
    label: 'Price: lowest',
    code: 1001
  },
  {
    label: 'Price: highest',
    code: 1002
  },
  {
    label: 'Rental Company: A to Z',
    code: 1003
  },
  {
    label: 'Rental Company: Z to A',
    code: 1004
  },
  {
    label: 'Car Type: A to Z',
    code: 1005
  },
  {
    label: 'Car Type: Z to A',
    code: 1006
  }
]
